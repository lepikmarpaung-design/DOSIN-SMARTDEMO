# DOSIN SMART v3 — End-to-End Prototype

Versi ini melanjutkan v2 menjadi alur yang lebih nyata:

**Warga → pilih layanan → isi data → pilih/upload dokumen → kirim → tersimpan di Supabase → Admin melihat pengajuan → Admin mengubah status → warga menerima perubahan status + notifikasi.**

## Setup
1. Buat project Supabase.
2. Buka SQL Editor dan jalankan `supabase/schema.sql`.
3. Di Supabase Authentication aktifkan Email/Password.
4. Salin `.env.example` menjadi `.env` dan isi URL + anon key.
5. Jalankan:
   - `npm install`
   - `npx expo start`
6. Scan QR dengan Expo Go.

## Membuat admin
Daftarkan akun seperti warga terlebih dahulu. Setelah profil terbentuk, jalankan SQL:
`update public.profiles set role='admin' where id='UUID_AKUN_ADMIN';`

Kemudian login ulang. Dashboard admin akan tersedia untuk role admin.

## Alur yang sudah diselesaikan
- Auth email/password.
- Profil warga otomatis dari metadata signup.
- Layanan dari database.
- Nomor pengajuan server-side.
- Upload PDF/gambar ke Storage privat.
- Metadata dokumen ke database.
- Tracking pengajuan.
- Detail dokumen dan signed URL 5 menit.
- Admin menerima daftar pengajuan.
- Admin: proses / minta perbaikan / setujui.
- Setiap perubahan status tercatat di `application_history`.
- Setiap perubahan status membuat `notifications`.
- Realtime update untuk aplikasi warga/admin.

## Catatan produksi
Ini belum merupakan sistem pemerintahan yang siap produksi. Sebelum digunakan warga:
- review RLS bersama pengelola Supabase;
- tambahkan validasi ukuran/jenis file di server;
- tambahkan antivirus/file scanning bila diperlukan;
- jangan menyimpan data sensitif di log;
- siapkan backup dan disaster recovery;
- siapkan audit log petugas;
- tambahkan pembatasan akses admin berbasis tugas;
- verifikasi SOP dan persyaratan resmi desa/Dukcapil;
- uji beban, keamanan, dan pemulihan akun;
- pertimbangkan nomor surat resmi dan tanda tangan elektronik sesuai prosedur yang berlaku.


## DOSIN SMART v4 — Android-ready foundation

Tambahan v4:
- `app.json` dengan nama aplikasi DOSIN SMART, package Android `id.dosin.smart`, iOS bundle identifier.
- `eas.json` untuk build preview/production menggunakan EAS.
- Logo SVG di `assets/logo.svg`.
- Statistik admin lebih lengkap.
- Notifikasi warga: daftar dan tandai sudah dibaca.
- Dukungan upload `Surat Hasil` oleh admin ke Storage privat.
- Index database tambahan untuk performa.
- RLS dokumen diperketat untuk owner/admin.
- Struktur siap dikembangkan menjadi APK/AAB.

### Build Android
1. Install EAS CLI: `npm install -g eas-cli`
2. Login: `eas login`
3. Jalankan `npm install`
4. Untuk APK internal: `eas build --platform android --profile preview`
5. Untuk rilis Play Store: `eas build --platform android --profile production`

Sebelum produksi, ganti package/bundle identifier bila perlu, buat kredensial signing melalui EAS, uji di perangkat Android nyata, dan lakukan audit RLS/Storage.


## v5 — Dynamic Service Forms

Form warga sekarang memakai konfigurasi `SERVICE_FORMS` di `App.js`, sehingga field dapat berbeda untuk KTP, KK, Akta Kelahiran, Akta Kematian, Domisili, SKU, SKTM, dan Pengantar Nikah.

Pencarian/filter aplikasi admin juga disiapkan melalui `searchApplications()` di API service.

Untuk produksi, ikuti `PRODUCTION-CHECKLIST.md`.


## v6 — Citizen/Admin UX Foundation

v6 menambahkan helper status badge, empty-state, ringkasan warga, unread notification count, daftar dokumen aplikasi, dan indeks tambahan. Detail UI/UX dan release flow ada di `UI-UX-SPEC.md`.


## v7 — Final Production Foundation

v7 menyiapkan metadata produksi Android, checklist QA/Play Store, changelog, dan pemeriksaan struktur proyek.

**Catatan:** APK/AAB produksi yang ditandatangani tetap harus dibuat melalui EAS/Android build dengan kredensial signing milik pemilik aplikasi.


## v8 — Release Candidate Foundation

v8 menambahkan branding splash SVG, metadata aplikasi versi 8.0.0, pemeriksaan struktur release, dan runbook go-live. Jalankan `python verify-release.py` sebelum build EAS.


## v9 — Production Validation

v9 menambahkan validasi form dasar di sisi aplikasi, metadata katalog layanan (deskripsi, estimasi hari, status aktif), dan deployment pack untuk staging/UAT/production serta keamanan dokumen.


## FINAL — Handoff

Jalankan `python verify-final.py` untuk pemeriksaan struktur final. Untuk produksi, ikuti `FINAL-HANDOFF.md` dan `FINAL-RELEASE-CHECKLIST.md`.


## Release Audit
See `RELEASE-AUDIT.md` for the final static audit. This is source-level verification; real device UAT and EAS signing are still required for production release.
