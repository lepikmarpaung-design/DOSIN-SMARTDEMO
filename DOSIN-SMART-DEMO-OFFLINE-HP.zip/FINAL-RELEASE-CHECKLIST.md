# DOSIN SMART v7 — Final Production & Play Store Checklist

## 1. Supabase production
- Create production Supabase project.
- Run `supabase/schema.sql`.
- Configure Auth Email/Password.
- Review every RLS policy.
- Keep `documents` bucket private.
- Configure backups and monitoring.
- Create one admin account manually and verify role.

## 2. Environment
Create `.env` from `.env.example` and fill:
- `EXPO_PUBLIC_SUPABASE_URL`
- `EXPO_PUBLIC_SUPABASE_ANON_KEY`

Never put the Supabase service-role key inside the mobile app.

## 3. Android build
Install EAS CLI, log in, then:
- `npm install`
- `eas build --platform android --profile preview` for internal APK testing.
- `eas build --platform android --profile production` for release AAB.

The signing credentials should be managed by EAS or your organization's secure keystore process.

## 4. Release QA
Test:
- Login/register/logout.
- KTP, KK, Akta and all configured forms.
- Required field validation.
- PDF/image upload.
- Tracking and status history.
- Notification read state.
- Admin process/repair/approve/reject/finish workflow.
- Result-letter upload.
- Document access boundaries.
- Slow internet and app restart during upload.
- Android back navigation.

## 5. Play Store
Prepare:
- App icon and feature graphic.
- Screenshots for supported device sizes.
- App description.
- Privacy policy URL.
- Data safety declarations.
- Contact/support information.
- Content rating.
- Production AAB.

## 6. Government/village operational readiness
Before real deployment:
- Match service forms to official village SOP.
- Define who may approve each service.
- Define document retention/deletion policy.
- Define admin account lifecycle.
- Define incident response for leaked/incorrect documents.
- Confirm requirements for official electronic signatures/stamps.

## Important
This repository is a production foundation. A signed production APK/AAB requires an Android/EAS build environment and your organization's signing credentials; it should not be fabricated or embedded into source code.
