import { supabase } from '../lib/supabase';

export const signUp = ({email,password,fullName,nik,noKk,phone,address}) =>
  supabase.auth.signUp({email,password,options:{data:{full_name:fullName,nik,no_kk:noKk,phone,address}}});

export const signIn = (email,password) =>
  supabase.auth.signInWithPassword({email,password});

export const signOut = () => supabase.auth.signOut();

export async function getProfile(userId) {
  return supabase.from('profiles').select('*').eq('id',userId).single();
}

export async function getServices() {
  return supabase.from('services').select('*').eq('active',true).order('category').order('name');
}

export async function getApplications(userId, isAdmin=false) {
  let q=supabase.from('applications')
    .select('*, services(name,category), profiles!applications_citizen_id_fkey(full_name,nik)')
    .order('created_at',{ascending:false});
  if(!isAdmin) q=q.eq('citizen_id',userId);
  return q;
}

export async function createApplication({userId,serviceId,formData}) {
  const {data:no,error:noError}=await supabase.rpc('next_application_no');
  if(noError) return {data:null,error:noError};
  const result=await supabase.from('applications').insert({
    application_no:no,citizen_id:userId,service_id:serviceId,form_data:formData
  }).select().single();
  if(!result.error) await supabase.from('application_history').insert({
    application_id:result.data.id,changed_by:userId,status:'menunggu_verifikasi',note:'Pengajuan dibuat'
  });
  return result;
}

export async function uploadDocument({userId,applicationId,asset,documentType}) {
  const ext=(asset.name?.split('.').pop()||'bin').toLowerCase();
  const path=`${userId}/${applicationId}/${Date.now()}-${documentType.replace(/[^a-z0-9]/gi,'_')}.${ext}`;
  const response=await fetch(asset.uri);
  const body=await response.arrayBuffer();
  const upload=await supabase.storage.from('documents').upload(path,body,{
    contentType:asset.mimeType||'application/octet-stream',upsert:false
  });
  if(upload.error) return upload;
  return supabase.from('documents').insert({
    application_id:applicationId,owner_id:userId,document_type:documentType,
    file_path:path,file_name:asset.name||path.split('/').pop(),
    mime_type:asset.mimeType||null,size_bytes:asset.size||null
  });
}

export async function getApplicationDetail(id) {
  const [a,h,d]=await Promise.all([
    supabase.from('applications').select('*, services(name,category), profiles!applications_citizen_id_fkey(full_name,nik,phone)').eq('id',id).single(),
    supabase.from('application_history').select('*').eq('application_id',id).order('created_at'),
    supabase.from('documents').select('*').eq('application_id',id).order('created_at')
  ]);
  return {application:a.data,history:h.data||[],documents:d.data||[],error:a.error||h.error||d.error};
}

export async function updateApplicationStatus({applicationId,status,note,adminId}) {
  return supabase.rpc('admin_update_application_status',{p_application_id:applicationId,p_status:status,p_note:note||'',p_admin_id:adminId});
}

export async function createSignedUrl(path) {
  return supabase.storage.from('documents').createSignedUrl(path,300);
}

export function subscribeToApplications(callback) {
  return supabase.channel('dosin-applications')
    .on('postgres_changes',{event:'*',schema:'public',table:'applications'},callback)
    .subscribe();
}

export function subscribeToMyApplications(userId,callback) {
  return supabase.channel(`dosin-user-${userId}`)
    .on('postgres_changes',{event:'*',schema:'public',table:'applications',filter:`citizen_id=eq.${userId}`},callback)
    .subscribe();
}


export async function getMyNotifications(userId) {
  const { data, error } = await supabase
    .from('notifications')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false });
  if (error) throw error;
  return data || [];
}

export async function markNotificationRead(id) {
  const { error } = await supabase
    .from('notifications')
    .update({ is_read: true })
    .eq('id', id);
  if (error) throw error;
}

export async function getAdminStats() {
  const { data, error } = await supabase
    .from('applications')
    .select('status');
  if (error) throw error;
  const rows = data || [];
  return {
    total: rows.length,
    waiting: rows.filter(x => x.status === 'menunggu_verifikasi').length,
    process: rows.filter(x => x.status === 'diproses').length,
    repair: rows.filter(x => x.status === 'perlu_perbaikan').length,
    approved: rows.filter(x => x.status === 'disetujui').length,
    done: rows.filter(x => x.status === 'selesai').length,
    rejected: rows.filter(x => x.status === 'ditolak').length,
  };
}

export async function adminUploadResultDocument({ applicationId, adminId, asset }) {
  const ext = (asset.name || 'hasil.pdf').split('.').pop().toLowerCase();
  const path = `admin-results/${applicationId}/${Date.now()}-${Math.random().toString(36).slice(2)}.${ext}`;
  const body = await (await fetch(asset.uri)).arrayBuffer();
  const { error: uploadError } = await supabase.storage
    .from('documents')
    .upload(path, body, { contentType: asset.mimeType || 'application/pdf', upsert: false });
  if (uploadError) throw uploadError;

  const { error } = await supabase.from('documents').insert({
    application_id: applicationId,
    document_type: 'Surat Hasil',
    file_name: asset.name || `Surat-Hasil.${ext}`,
    storage_path: path,
    uploaded_by: adminId,
  });
  if (error) throw error;
  return path;
}


export async function searchApplications({query = "", status = "all", serviceId = "all"} = {}) {
  let q = supabase
    .from('applications')
    .select('*, services(name)')
    .order('created_at', { ascending: false });
  if (status !== "all") q = q.eq('status', status);
  if (serviceId !== "all") q = q.eq('service_id', serviceId);
  if (query.trim()) {
    const safe = query.trim().replace(/[%_]/g, '');
    q = q.or(`application_no.ilike.%${safe}%,user_id.ilike.%${safe}%`);
  }
  const { data, error } = await q;
  if (error) throw error;
  return data || [];
}


export async function getCitizenSummary(userId) {
  const { data, error } = await supabase
    .from('applications')
    .select('status')
    .eq('user_id', userId);
  if (error) throw error;
  const rows = data || [];
  return {
    total: rows.length,
    waiting: rows.filter(x => x.status === 'menunggu_verifikasi').length,
    process: rows.filter(x => x.status === 'diproses').length,
    repair: rows.filter(x => x.status === 'perlu_perbaikan').length,
    done: rows.filter(x => x.status === 'selesai').length,
  };
}

export async function getUnreadNotificationCount(userId) {
  const { count, error } = await supabase
    .from('notifications')
    .select('*', { count: 'exact', head: true })
    .eq('user_id', userId)
    .eq('is_read', false);
  if (error) throw error;
  return count || 0;
}

export async function getApplicationDocuments(applicationId) {
  const { data, error } = await supabase
    .from('documents')
    .select('*')
    .eq('application_id', applicationId)
    .order('created_at', { ascending: true });
  if (error) throw error;
  return data || [];
}


export async function adminTransitionApplication({applicationId, newStatus, note, adminId}) {
  const { data, error } = await supabase.rpc('admin_transition_application', {
    p_application_id: applicationId,
    p_new_status: newStatus,
    p_note: note || null,
    p_admin_id: adminId,
  });
  if (error) throw error;
  return data;
}

export async function getMyResultDocuments(applicationId) {
  const { data, error } = await supabase
    .from('documents')
    .select('*')
    .eq('application_id', applicationId)
    .eq('document_type', 'Surat Hasil')
    .order('created_at', { ascending: false });
  if (error) throw error;
  return data || [];
}
