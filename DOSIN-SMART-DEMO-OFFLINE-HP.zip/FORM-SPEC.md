# DOSIN SMART v4 — Form Service Specification

Gunakan pola berikut ketika menambah layanan baru.

## KTP
- NIK
- Nama lengkap
- Nomor KK
- Alamat
- Alasan pengajuan: baru/perubahan/hilang/rusak
- Dokumen: KK, foto KTP lama (jika ada), dokumen pendukung

## KK
- Nomor KK lama (opsional)
- Kepala keluarga
- Alamat
- Jenis perubahan: baru/perubahan/pisah/pecah KK
- Keterangan
- Dokumen pendukung

## Akta Kelahiran
- Nama anak
- Tempat lahir
- Tanggal lahir
- Nama ayah
- Nama ibu
- Nomor KK
- Dokumen: KK, surat keterangan lahir, dokumen orang tua

## Akta Kematian
- Nama almarhum
- NIK
- Tempat/tanggal meninggal
- Nama pelapor
- Hubungan dengan almarhum
- Dokumen pendukung

## Surat Domisili / SKU / SKTM / Pengantar Nikah
Gunakan:
- Nama
- NIK
- Alamat
- Keperluan
- Keterangan
- Dokumen pendukung (jika diperlukan)
