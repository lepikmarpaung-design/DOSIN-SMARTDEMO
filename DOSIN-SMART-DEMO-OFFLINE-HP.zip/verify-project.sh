#!/usr/bin/env bash
set -e
echo "DOSIN SMART v7 project verification"
test -f App.js
test -f app.json
test -f eas.json
test -f supabase/schema.sql
test -f .env.example
echo "Core files: OK"
echo "Run npm install, then npx expo start."
