import os, json, re, sys
root=os.path.dirname(os.path.abspath(__file__))
required=[
 "App.js","app.json","eas.json",".env.example",
 "src/services/api.js","supabase/schema.sql",
 "FINAL-HANDOFF.md","FINAL-RELEASE-CHECKLIST.md"
]
missing=[x for x in required if not os.path.exists(os.path.join(root,x))]
if missing:
    print("Missing:", missing); sys.exit(1)
cfg=json.load(open(os.path.join(root,"app.json"),encoding="utf-8"))
assert cfg["expo"]["name"]=="DOSIN SMART"
assert cfg["expo"]["version"]=="9.0.0"
app=open(os.path.join(root,"App.js"),encoding="utf-8").read()
api=open(os.path.join(root,"src/services/api.js"),encoding="utf-8").read()
sql=open(os.path.join(root,"supabase/schema.sql"),encoding="utf-8").read()
checks=[
 ("dynamic forms","SERVICE_FORMS" in app),
 ("form validation","validateServiceForm" in app),
 ("admin transition","adminTransitionApplication" in api),
 ("database workflow","admin_transition_application" in sql),
 ("private documents","documents" in sql and "storage" in sql),
]
bad=[name for name,ok in checks if not ok]
if bad:
    print("Failed checks:",bad); sys.exit(1)
print("DOSIN SMART FINAL static verification: PASS")
