# DOSIN SMART — FINAL HANDOFF

## What is complete
- Citizen authentication foundation
- Village service catalog
- Dynamic service forms
- Document upload foundation
- Private Supabase Storage
- Automatic application numbers
- Application tracking
- Status history
- Citizen notifications
- Admin dashboard foundation
- Admin document/result upload foundation
- Controlled application status transitions
- RLS-oriented database structure
- Android/iOS app metadata
- EAS build profiles
- Release and UAT documentation
- Pink/white/gold DOSIN SMART branding

## What must be done outside this repository
1. Create and configure the production Supabase project.
2. Apply and review `supabase/schema.sql`.
3. Configure `.env` with the production URL and anon key.
4. Create/administer real admin accounts.
5. Test the complete workflow with dummy data.
6. Run EAS preview build on physical Android devices.
7. Fix any device-specific issues found in UAT.
8. Run EAS production build and obtain the signed AAB.
9. Complete Google Play Console declarations and publish.

## Never do this
- Never put a Supabase service-role key in the mobile app.
- Never make citizen document storage public.
- Never use real citizen data for initial development tests.
- Never share an admin account between staff.

## Definition of done
The app is considered production-ready only after a real UAT cycle passes:
registration → service selection → form → upload → submission → admin verification → optional repair → approval/rejection → result document → completion → citizen notification.
