# DOSIN SMART v5 — Production Checklist

## Alur warga
- Registrasi / login
- Pilih layanan
- Form dinamis sesuai layanan
- Upload dokumen
- Nomor pengajuan otomatis
- Tracking status
- Riwayat status
- Notifikasi
- Melihat surat hasil

## Alur admin
- Dashboard statistik
- Daftar pengajuan
- Pencarian nomor pengajuan
- Filter status
- Filter layanan
- Buka detail pengajuan
- Verifikasi dokumen
- Minta perbaikan
- Proses
- Setujui
- Upload surat hasil
- Tandai selesai

## Sebelum go-live
- [ ] Ganti kredensial Supabase
- [ ] Review semua RLS policy
- [ ] Aktifkan email verification bila diperlukan
- [ ] Validasi ukuran/tipe file di server
- [ ] Tambahkan antivirus/malware scanning untuk upload
- [ ] Backup database
- [ ] Audit log admin
- [ ] Uji perangkat Android kelas bawah
- [ ] Uji koneksi lambat/offline
- [ ] Uji beban
- [ ] Uji pemulihan backup
- [ ] Pastikan format layanan sesuai SOP pemerintah desa
- [ ] Pastikan dokumen/TTD digital mengikuti ketentuan resmi
