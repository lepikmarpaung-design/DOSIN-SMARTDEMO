import json, os, sys
root=os.path.dirname(os.path.abspath(__file__))
required=["App.js","app.json","eas.json","supabase/schema.sql",".env.example","README.md"]
missing=[p for p in required if not os.path.exists(os.path.join(root,p))]
if missing:
    print("MISSING:", ", ".join(missing)); sys.exit(1)
cfg=json.load(open(os.path.join(root,"app.json"),encoding="utf-8"))
assert cfg["expo"]["name"]=="DOSIN SMART"
assert cfg["expo"]["android"]["package"]=="id.dosin.smart"
assert cfg["expo"]["version"]=="8.0.0"
print("DOSIN SMART v8 release structure: OK")
