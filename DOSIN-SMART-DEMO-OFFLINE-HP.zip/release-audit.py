import os, re, json
ROOT=os.path.dirname(os.path.abspath(__file__))
checks = {
 "App.js": os.path.exists(os.path.join(ROOT,"App.js")),
 "app.json": os.path.exists(os.path.join(ROOT,"app.json")),
 "eas.json": os.path.exists(os.path.join(ROOT,"eas.json")),
 "schema": os.path.exists(os.path.join(ROOT,"supabase","schema.sql")),
 "api": os.path.exists(os.path.join(ROOT,"src","services","api.js")),
}
print("DOSIN SMART RELEASE AUDIT")
for k,v in checks.items(): print(("PASS " if v else "FAIL ")+k)
cfg=json.load(open(os.path.join(ROOT,"app.json"),encoding="utf-8"))
print("version:",cfg["expo"]["version"])
print("android package:",cfg["expo"]["android"]["package"])
