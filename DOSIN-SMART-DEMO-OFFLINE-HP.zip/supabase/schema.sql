create extension if not exists "pgcrypto";

do $$ begin
  create type public.user_role as enum ('warga','admin');
exception when duplicate_object then null; end $$;

do $$ begin
  create type public.application_status as enum ('menunggu_verifikasi','diproses','perlu_perbaikan','disetujui','ditolak','selesai');
exception when duplicate_object then null; end $$;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null,
  nik text unique,
  no_kk text,
  phone text,
  address text,
  role public.user_role not null default 'warga',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.services (
  id uuid primary key default gen_random_uuid(),
  name text not null, category text not null, description text,
  requirements jsonb not null default '[]'::jsonb,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.applications (
  id uuid primary key default gen_random_uuid(),
  application_no text unique not null,
  citizen_id uuid not null references public.profiles(id) on delete cascade,
  service_id uuid not null references public.services(id),
  status public.application_status not null default 'menunggu_verifikasi',
  form_data jsonb not null default '{}'::jsonb,
  admin_note text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.documents (
  id uuid primary key default gen_random_uuid(),
  application_id uuid not null references public.applications(id) on delete cascade,
  owner_id uuid not null references public.profiles(id) on delete cascade,
  document_type text not null, file_path text not null, file_name text not null,
  mime_type text, size_bytes bigint, created_at timestamptz not null default now()
);

create table if not exists public.application_history (
  id uuid primary key default gen_random_uuid(),
  application_id uuid not null references public.applications(id) on delete cascade,
  changed_by uuid references public.profiles(id),
  status public.application_status not null,
  note text, created_at timestamptz not null default now()
);

create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  application_id uuid references public.applications(id) on delete cascade,
  title text not null, message text not null,
  read_at timestamptz, created_at timestamptz not null default now()
);

create index if not exists applications_citizen_idx on public.applications(citizen_id);
create index if not exists applications_status_idx on public.applications(status);
create index if not exists notifications_user_idx on public.notifications(user_id,created_at desc);

insert into public.services(name,category,description,requirements) values
('Pengajuan KTP','Kependudukan','Pengajuan administrasi KTP','["Kartu Keluarga","Foto KTP"]'),
('Pengajuan KK','Kependudukan','Pengajuan atau perubahan Kartu Keluarga','["Kartu Keluarga","Dokumen pendukung"]'),
('Akta Kelahiran','Kelahiran & Keluarga','Administrasi akta kelahiran','["Kartu Keluarga","Surat keterangan lahir"]'),
('Akta Kematian','Kelahiran & Keluarga','Administrasi akta kematian','["Kartu Keluarga","Surat keterangan kematian"]'),
('Surat Domisili','Surat Desa','Surat keterangan domisili','["Kartu Keluarga"]'),
('Surat Keterangan Usaha','Surat Desa','Surat keterangan usaha warga','["Kartu Keluarga","Dokumen usaha"]'),
('Surat Tidak Mampu','Surat Desa','Surat keterangan tidak mampu','["Kartu Keluarga"]'),
('Surat Pengantar Nikah','Pernikahan','Administrasi pengantar nikah','["Kartu Keluarga","KTP"]')
on conflict do nothing;

alter table public.profiles enable row level security;
alter table public.services enable row level security;
alter table public.applications enable row level security;
alter table public.documents enable row level security;
alter table public.application_history enable row level security;
alter table public.notifications enable row level security;

create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path=public
as $$ select exists(select 1 from public.profiles where id=auth.uid() and role='admin') $$;

drop policy if exists "profiles own read" on public.profiles;
create policy "profiles own read" on public.profiles for select using(id=auth.uid() or public.is_admin());
drop policy if exists "profiles own insert" on public.profiles;
create policy "profiles own insert" on public.profiles for insert with check(id=auth.uid());
drop policy if exists "profiles own update" on public.profiles;
create policy "profiles own update" on public.profiles for update using(id=auth.uid() or public.is_admin());

drop policy if exists "services public read" on public.services;
create policy "services public read" on public.services for select using(active=true or public.is_admin());
drop policy if exists "services admin write" on public.services;
create policy "services admin write" on public.services for all using(public.is_admin()) with check(public.is_admin());

drop policy if exists "applications read" on public.applications;
create policy "applications read" on public.applications for select using(citizen_id=auth.uid() or public.is_admin());
drop policy if exists "applications insert" on public.applications;
create policy "applications insert" on public.applications for insert with check(citizen_id=auth.uid());
drop policy if exists "applications admin update" on public.applications;
create policy "applications admin update" on public.applications for update using(public.is_admin());

drop policy if exists "documents read" on public.documents;
create policy "documents read" on public.documents for select using(owner_id=auth.uid() or public.is_admin());
drop policy if exists "documents insert" on public.documents;
create policy "documents insert" on public.documents for insert with check(owner_id=auth.uid());
drop policy if exists "documents delete" on public.documents;
create policy "documents delete" on public.documents for delete using(owner_id=auth.uid() or public.is_admin());

drop policy if exists "history read" on public.application_history;
create policy "history read" on public.application_history for select using(public.is_admin() or exists(select 1 from public.applications a where a.id=application_id and a.citizen_id=auth.uid()));
drop policy if exists "history insert" on public.application_history;
create policy "history insert" on public.application_history for insert with check(changed_by=auth.uid() or public.is_admin());

drop policy if exists "notifications own read" on public.notifications;
create policy "notifications own read" on public.notifications for select using(user_id=auth.uid() or public.is_admin());
drop policy if exists "notifications own update" on public.notifications;
create policy "notifications own update" on public.notifications for update using(user_id=auth.uid() or public.is_admin());

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path=public
as $$
begin
 insert into public.profiles(id,full_name,nik,no_kk,phone,address)
 values(new.id,coalesce(new.raw_user_meta_data->>'full_name','Warga DOSIN SMART'),
 new.raw_user_meta_data->>'nik',new.raw_user_meta_data->>'no_kk',
 new.raw_user_meta_data->>'phone',new.raw_user_meta_data->>'address')
 on conflict(id) do nothing;
 return new;
end $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();

create or replace function public.next_application_no()
returns text language plpgsql security definer set search_path=public
as $$
declare seq integer;
begin
 select count(*)+1 into seq from public.applications where created_at::date=current_date;
 return 'DS-'||to_char(current_date,'YYYYMMDD')||'-'||lpad(seq::text,4,'0');
end $$;

create or replace function public.admin_update_application_status(
 p_application_id uuid,p_status public.application_status,p_note text,p_admin_id uuid
) returns void language plpgsql security definer set search_path=public
as $$
declare citizen uuid; svc text;
begin
 if not exists(select 1 from public.profiles where id=p_admin_id and role='admin') then
   raise exception 'Akses admin diperlukan';
 end if;
 select citizen_id into citizen from public.applications where id=p_application_id;
 if citizen is null then raise exception 'Pengajuan tidak ditemukan'; end if;
 update public.applications set status=p_status,admin_note=nullif(p_note,''),updated_at=now() where id=p_application_id;
 insert into public.application_history(application_id,changed_by,status,note) values(p_application_id,p_admin_id,p_status,p_note);
 select name into svc from public.services s join public.applications a on a.service_id=s.id where a.id=p_application_id;
 insert into public.notifications(user_id,application_id,title,message)
 values(citizen,p_application_id,'Status pengajuan berubah',
 'Pengajuan '||coalesce(svc,'layanan desa')||' sekarang: '||replace(p_status::text,'_',' ')||
 case when p_note<>'' then '. Catatan: '||p_note else '.' end);
end $$;

-- Private storage bucket.
insert into storage.buckets(id,name,public) values('documents','documents',false)
on conflict(id) do nothing;

drop policy if exists "document upload own folder" on storage.objects;
create policy "document upload own folder" on storage.objects for insert
with check(bucket_id='documents' and (storage.foldername(name))[1]=auth.uid()::text);
drop policy if exists "document read own folder" on storage.objects;
create policy "document read own folder" on storage.objects for select
using(bucket_id='documents' and ((storage.foldername(name))[1]=auth.uid()::text or public.is_admin()));
drop policy if exists "document delete own folder" on storage.objects;
create policy "document delete own folder" on storage.objects for delete
using(bucket_id='documents' and ((storage.foldername(name))[1]=auth.uid()::text or public.is_admin()));

-- Enable realtime for app workflow (safe to run repeatedly by checking publication membership manually if needed).
do $$ begin
  alter publication supabase_realtime add table public.applications;
exception when duplicate_object then null; end $$;
do $$ begin
  alter publication supabase_realtime add table public.notifications;
exception when duplicate_object then null; end $$;


-- v4 hardening / indexes / admin result document access
create index if not exists idx_documents_application_id on public.documents(application_id);
create index if not exists idx_applications_service_id on public.applications(service_id);
create index if not exists idx_notifications_user_read on public.notifications(user_id, is_read);

-- Allow admins to insert result documents and citizens to read documents attached to their own applications.
drop policy if exists "documents_insert_admin" on public.documents;
create policy "documents_insert_admin"
on public.documents for insert
to authenticated
with check (
  public.is_admin()
  and uploaded_by = auth.uid()
);

drop policy if exists "documents_select_owner_or_admin" on public.documents;
create policy "documents_select_owner_or_admin"
on public.documents for select
to authenticated
using (
  public.is_admin()
  or exists (
    select 1 from public.applications a
    where a.id = application_id and a.user_id = auth.uid()
  )
);


-- v6 notification/document performance
create index if not exists idx_notifications_created_at on public.notifications(created_at desc);
create index if not exists idx_documents_created_at on public.documents(created_at asc);

drop policy if exists "notifications_update_own" on public.notifications;
create policy "notifications_update_own"
on public.notifications for update
to authenticated
using (user_id = auth.uid())
with check (user_id = auth.uid());


-- v9 service catalog metadata
alter table public.services add column if not exists description text;
alter table public.services add column if not exists estimated_days integer default 3;
alter table public.services add column if not exists is_active boolean default true;

update public.services set description = coalesce(description, 'Layanan administrasi desa digital')
where description is null;

update public.services set estimated_days = coalesce(estimated_days, 3)
where estimated_days is null;


-- DOSIN SMART FINAL — controlled workflow transitions
create or replace function public.admin_transition_application(
  p_application_id uuid,
  p_new_status public.application_status,
  p_note text default null,
  p_admin_id uuid default auth.uid()
)
returns public.applications
language plpgsql
security definer
set search_path = public
as $$
declare
  v_app public.applications;
  v_old public.application_status;
begin
  if not public.is_admin() then
    raise exception 'admin_only';
  end if;

  select * into v_app from public.applications
  where id = p_application_id
  for update;

  if not found then
    raise exception 'application_not_found';
  end if;

  v_old := v_app.status;

  if v_old = p_new_status then
    return v_app;
  end if;

  if p_new_status = 'diproses' and v_old not in ('menunggu_verifikasi','perlu_perbaikan') then
    raise exception 'invalid_transition';
  elsif p_new_status = 'perlu_perbaikan' and v_old not in ('menunggu_verifikasi','diproses') then
    raise exception 'invalid_transition';
  elsif p_new_status = 'disetujui' and v_old not in ('diproses','perlu_perbaikan') then
    raise exception 'invalid_transition';
  elsif p_new_status = 'ditolak' and v_old not in ('menunggu_verifikasi','diproses','perlu_perbaikan') then
    raise exception 'invalid_transition';
  elsif p_new_status = 'selesai' and v_old not in ('disetujui') then
    raise exception 'invalid_transition';
  end if;

  update public.applications
  set status = p_new_status,
      admin_note = coalesce(p_note, admin_note),
      updated_at = now()
  where id = p_application_id
  returning * into v_app;

  insert into public.application_history(application_id,status,note,changed_by)
  values (p_application_id,p_new_status,p_note,p_admin_id);

  insert into public.notifications(user_id,title,message)
  values (
    v_app.user_id,
    'Status pengajuan diperbarui',
    'Pengajuan ' || v_app.application_no || ' sekarang: ' || replace(p_new_status,'_',' ')
  );

  return v_app;
end;
$$;

grant execute on function public.admin_transition_application(uuid, public.application_status, text, uuid) to authenticated;
