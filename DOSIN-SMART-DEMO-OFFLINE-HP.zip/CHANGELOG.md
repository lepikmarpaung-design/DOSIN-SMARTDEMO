# Changelog

## 7.0.0
- Final production foundation.
- Android version code 7.
- Production environment metadata.
- Release and Play Store checklist.
- Security guidance for Supabase keys and Storage.
- QA and operational readiness checklist.

## 6.0.0
- Citizen/admin UX foundation.
- Status badges and empty states.
- Citizen summary and unread notifications.
- Document listing helpers.


## 8.0.0
- Release-candidate metadata.
- Splash SVG branding.
- Automated release structure verification.
- Go-live runbook.


## 9.0.0
- Client-side service form validation.
- Service catalog metadata.
- Production deployment/UAT pack.


## FINAL
- Controlled admin workflow transitions.
- Final handoff and definition-of-done documentation.
- Static release verification.


## RELEASE AUDIT
- Static source-level release audit report and verifier added.
