# DOSIN SMART v8 — Go-Live Runbook

## A. Database
1. Create production Supabase project.
2. Run `supabase/schema.sql`.
3. Verify RLS with a warga account and an admin account.
4. Verify Storage bucket `documents` is private.
5. Create backup/monitoring policy.

## B. App configuration
1. Copy `.env.example` to `.env`.
2. Set production Supabase URL and anon key.
3. Run `npm install`.
4. Run `python verify-release.py`.

## C. Device QA
- Android login/register
- Service selection
- Dynamic form validation
- PDF/image upload
- Tracking
- Notifications
- Admin actions
- Result document access
- Logout/re-login

## D. Build
Preview:
`eas build --platform android --profile preview`

Production:
`eas build --platform android --profile production`

## E. Release
Upload the resulting AAB to Google Play Console.
Complete store listing, privacy policy, Data Safety, content rating and testing track before production rollout.

## F. Security
Never ship a Supabase service-role key in the app.
Do not make citizen documents public.
Use least-privilege admin accounts.
Review audit logs and backups regularly.
