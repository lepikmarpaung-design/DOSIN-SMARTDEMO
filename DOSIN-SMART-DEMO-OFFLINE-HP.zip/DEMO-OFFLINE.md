# DOSIN SMART — Demo Offline

Versi ini disiapkan untuk melihat UI/alur aplikasi tanpa Supabase production.

## Catatan penting
Paket ini adalah **source project**, bukan APK. Untuk menjadi APK Android tetap diperlukan proses build Android (misalnya EAS Build/cloud build).

## Isi demo
- Login/Register UI
- Beranda
- Katalog layanan
- Form KTP/KK/Akta dan layanan desa lainnya
- Tracking
- Profil
- Dashboard admin
- Branding pink/putih/gold DOSIN SMART

## Konfigurasi
Mode demo ditandai di `App.js` dengan:
`OFFLINE_DEMO_MODE = true`

Jika ingin koneksi ke Supabase production, gunakan konfigurasi `.env` dan schema pada folder `supabase/`.

## Jalur dari HP
Project dapat diunggah ke layanan build cloud yang mendukung Expo/EAS. APK hasil build kemudian dapat diunduh dan dipasang di Android.
