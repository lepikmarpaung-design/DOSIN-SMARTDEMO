# DOSIN SMART v9 — Production Deployment Pack

## Environment separation
Use separate Supabase projects for:
- Development
- Staging/UAT
- Production

Never test destructive migrations directly on production.

## Form validation
Client validation improves UX, but sensitive/business-rule validation must also be enforced server-side before official approval.

## File security
For every uploaded document:
- allow only expected MIME types/extensions
- enforce maximum size
- generate randomized storage paths
- keep Storage private
- use short-lived signed URLs
- consider malware scanning before staff opens a file

## Admin security
- Use individual admin accounts.
- Do not share passwords.
- Enable stronger authentication where available.
- Remove admin role immediately when staff changes.
- Review audit/history records.

## Operational workflow
MENUNGGU_VERIFIKASI
→ DIPROSES
→ PERLU_PERBAIKAN (optional loop)
→ DISETUJUI
→ SURAT HASIL
→ SELESAI

Rejected applications should remain auditable.

## UAT acceptance criteria
A service is ready only when:
1. Required fields are validated.
2. Documents upload correctly.
3. Citizen can track status.
4. Admin can act on the application.
5. Citizen receives notification.
6. Result document is accessible only to authorized users.
7. Restarting the app does not lose already submitted applications.
