# DOSIN SMART — CLEAN v1

Demo offline yang dibuat ulang dari nol untuk menghindari crash dari source lama.

Fitur:
- Logo DOSIN SMART sebagai icon aplikasi
- Splash logo
- Login demo
- Beranda
- 8 layanan desa
- Form pengajuan
- Tracking
- Profil
- Pink + putih + aksen gold
- Tanpa Supabase dan tanpa library tambahan

Build dari HP:
1. Upload isi folder ini ke root GitHub.
2. Pastikan `App.js`, `app.json`, `package.json`, `assets/`, dan `.github/workflows/` ada.
3. GitHub → Actions → Build DOSIN SMART APK → Run workflow.
4. Setelah Success → Artifacts → DOSIN-SMART-APK.
5. Ekstrak ZIP dan install `app-debug.apk`.

Ini demo offline; belum terhubung ke database desa.
