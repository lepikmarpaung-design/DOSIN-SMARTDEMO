from pathlib import Path
import json

root = Path(__file__).parent
required = ["App.js", "app.json", "package.json", "src/services/api.js", "supabase/schema.sql"]
missing = [x for x in required if not (root/x).exists()]
print("DOSIN SMART Demo Offline verification")
print("Missing:", missing)
if missing:
    raise SystemExit(1)
data = json.loads((root/"app.json").read_text())
print("Name:", data["expo"]["name"])
print("Package:", data["expo"]["android"]["package"])
print("OK")
