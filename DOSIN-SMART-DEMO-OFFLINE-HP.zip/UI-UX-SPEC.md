# DOSIN SMART v6 — UI/UX & Release Specification

## Warga
1. Beranda: greeting, ringkasan pengajuan, tombol layanan utama, status terakhir.
2. Layanan: kartu layanan dengan ikon, nama, deskripsi singkat.
3. Form: field spesifik layanan, indikator dokumen wajib, progress submit.
4. Tracking: timeline status + catatan petugas.
5. Dokumen: daftar file, status upload, akses surat hasil.
6. Notifikasi: badge unread + mark as read.
7. Profil: identitas warga, logout, versi aplikasi.

## Admin
1. Dashboard: total, menunggu, diproses, perbaikan, selesai.
2. Search: nomor pengajuan / identitas yang diizinkan.
3. Filter: status dan layanan.
4. Detail: data pemohon, form data, dokumen, history.
5. Tindakan: proses, minta perbaikan, setujui, tolak, selesai.
6. Surat hasil: upload ke storage privat dan kirim notifikasi.

## Prinsip desain
- Pink #F52B82 sebagai aksen utama.
- White sebagai background.
- Gold #D4AF37 sebagai aksen premium.
- Card radius lembut, tipografi jelas, tombol besar.
- Fokus pada aksesibilitas dan penggunaan di Android kelas menengah/bawah.
